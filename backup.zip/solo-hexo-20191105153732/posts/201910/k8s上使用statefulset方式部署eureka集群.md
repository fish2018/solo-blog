title: k8s上使用statefulset方式部署eureka集群
date: '2019-10-24 14:07:32'
updated: '2019-10-24 18:42:12'
tags: [devops]
permalink: /articles/2019/10/24/1571897252380.html
---
![](https://img.hacpai.com/bing/20190813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

`statefulset-eureka.yml`
```
apiVersion: v1
kind: ConfigMap
metadata:
  name: {APP_NAME}-cm
data:
  # if you want to deploy n instances of eureka cluster, 
  # you should set eureka_service_address: http://eureka-0.eureka:8761/eureka,...,http://eureka-(n-1).eureka:8761/eureka
  eureka_service_address: http://{APP_NAME}-0.{APP_NAME}:8888/eureka,http://{APP_NAME}-1.{APP_NAME}:8888/eureka,http://{APP_NAME}-2.{APP_NAME}:8888/eureka
---
apiVersion: v1
kind: Service
metadata:
  name: {APP_NAME}
  labels:
    app: {APP_NAME}
spec:
  type: NodePort
  ports:
  - port: 8888
    targetPort: 8888
    name: {APP_NAME}
  selector:
    app: {APP_NAME}
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {APP_NAME}
spec:
  serviceName: '{APP_NAME}'
  # n instances
  replicas: 3
  selector:
    matchLabels:
      app: {APP_NAME}
  template:
    metadata:
      labels:
        app: {APP_NAME}
    spec:
      imagePullSecrets:
      - name: hhotel-registry
      containers:
      - args:
        - -javaagent:agent/skywalking-agent.jar
        - -Dskywalking.collector.backend_service=apm2.hhotel.com:11800
        - -Dskywalking.agent.service_name={SPRING_PROFILE}-{PROJECT}
        - -Dspring.profiles.active={SPRING_PROFILE}
        - -Dapollo.bootstrap.enabled=true
        {APOLLO_ENV}
        {APOLLO_NS}
        {APOLLO_APPIP}
        {APOLLO_META}
        - -jar
        - -server
        - -Xms1024m
        - -Xmx1024m
        - -Xss512k
        - -XX:MetaspaceSize=256m
        - -XX:MaxMetaspaceSize=256m
        - -Dserver.port=8888
        - -Dport=8888
        - {APP_NAME}.jar
        command:
        - java
        name: {APP_NAME}
        image: {IMAGE_URL}
        ports:
        - containerPort: 8888
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "1200Mi"
            cpu: "500m"
#        readinessProbe:
#          httpGet:
#            path: /actuator/health
#            port: 8888
#            scheme: HTTP
#          initialDelaySeconds: 10
#          timeoutSeconds: 2
#          periodSeconds: 10    
        env:
        - name: EURAKE_HOST
          valueFrom:
            configMapKeyRef:
              name: {APP_NAME}-cm
              key: eureka_service_address
        - name: POD_NAME
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        - name: HOST_NAME
          value: "$(POD_NAME).{APP_NAME}"

```

`pipeline`
```
pipeline {
    agent any
    
    tools {
        maven 'mvn-3.5.4'
    }
    
    parameters{
        gitParameter branchFilter: '.*k8s.*', tagFilter: '.*', defaultValue: 'develop', name: 'TAG', type: 'PT_BRANCH_TAG', selectedValue: 'TOP', sortMode: 'DESCENDING_SMART'
    }
    
    environment {
        GIT = 'http://scm.hhotel.com/bzy-server/bzy-eureka.git'
        IMAGE_GROUP = "bzy" //对应harbor镜像分组
        // APOLLO_SERVER = "http://apollo-cfg2.hhotel.com:8082"
        // MORE_CFG = ",common.yml"
        // APOLLO_ENV="- -Denv=$ENV"
        // APOLLO_NS="- -Dapollo.bootstrap.namespaces=${PROJECT}.yml${MORE_CFG}"
        // APOLLO_APPIP="- -Dapp.id=${IMAGE_GROUP}"
        // APOLLO_META="- -Dapollo.meta=${APOLLO_SERVER}"
        APOLLO_ENV=" "
        APOLLO_NS=" "
        APOLLO_APPIP=" "
        APOLLO_META=" "
        K8S_NAMESPACE = "${IMAGE_GROUP}-${ENV}"
        PROJECT = sh(script: "echo ${GIT} | awk -F '/' '{print \$NF}' | awk -F '.' '{print \$1}'", returnStdout: true).trim()
        ENV = sh(script: "echo ${JOB_BASE_NAME} | awk -F '-' '{print \$1}'", returnStdout: true).trim()
        HARBOR_HOST = 'registry.hhotel.com'
        DOCKER_IMAGE = "${IMAGE_GROUP}/${JOB_BASE_NAME}:${BUILD_ID}"
        MAIL_TO = "yunwei@hhotel.com"
        ZIP = "target"
        CHECK_TAG = "${TAG}" // 分支或tag
        TIME = sh(script: "date '+%Y%m%d%H%M%S'", returnStdout: true).trim()
    }
    
    stages {
        
        stage ('克隆代码') {
            steps {
                deleteDir() // 清理工作目录
                git credentialsId: '9c9b7b17-04d5-47de-9b8f-6207a78e6973', url: "${GIT}" 
                sh '[ -n "${CHECK_TAG}" ] &&  git checkout ${CHECK_TAG} ||  { echo -e "切换至指定的tag的版本，tag：${CHECK_TAG} 不存在或为空，请检查输入的tag!" && exit 111; }'
            }
        }
        
        stage ('编译打包') {
            steps {
                sh "mvn clean && mvn -U -Dmaven.test.skip=true install"
                // archiveArtifacts artifacts: '**/target/*.jar', fingerprint: true, onlyIfSuccessful: true // 归档制品
            }
        }
        
        stage('Docker Build') {
            steps {
                sh "/usr/bin/cp -f /data/tools/Dockerfile ."
                sh "/usr/bin/cp -r -f /data/tools/agent ."
                sh "sed -i -e 's#{SW_AGENT_NAME:Your_ApplicationName}#${JOB_BASE_NAME}#g' agent/config/agent.config"
                sh "sudo docker build --build-arg JAR_FILE=${PROJECT}.jar -t ${HARBOR_HOST}/${DOCKER_IMAGE} ."
                sh "sudo docker push ${HARBOR_HOST}/${DOCKER_IMAGE}"
                sh "sudo docker rmi ${HARBOR_HOST}/${DOCKER_IMAGE}"
            }
        }
        
        stage('Deploy') {
            steps {
              echo "${ENV}"
              sh "kubectl config use-context dev-test-k8s && kubectl cluster-info && kubectl get nodes"
              sh "cp /data/tools/statefulset-eureka.yml deployment.yml"
              sh "sed -i -e 's#{IMAGE_URL}#${HARBOR_HOST}/${DOCKER_IMAGE}#g;s#{APP_NAME}#${PROJECT}#g;s#{SPRING_PROFILE}#${ENV}#g;s#{PROJECT}#${PROJECT}#g;s#{APOLLO_ENV}#${APOLLO_ENV}#g;s#{APOLLO_NS}#${APOLLO_NS}#g;s#{APOLLO_APPIP}#${APOLLO_APPIP}#g;s#{APOLLO_META}#${APOLLO_META}#g' deployment.yml"
              sh "kubectl apply -f deployment.yml --namespace=${K8S_NAMESPACE}"
            }
        }
        
        
    }
    
    post {
        always {
            // deleteDir() // 清理工作空间
            mail to: "${MAIL_TO}", 
                subject: "[${currentBuild.currentResult}] Pipeline: ${currentBuild.fullDisplayName}", 
                body: "<b>Project</b>: ${JOB_NAME} <br> <b>Git</b>: ${GIT} <br> <b>Branch or Tag</b>: ${CHECK_TAG} <br><b>Build Number</b>: ${BUILD_NUMBER} <br> \
                <b>Build Status</b>: ${currentBuild.currentResult} <br> <b>URL de build</b>: ${env.BUILD_URL} <br> <b>Duration</b>:${currentBuild.durationString} <br> \
                <b>Cause</b>: ${currentBuild.rawBuild.getCause(hudson.model.Cause$UserIdCause).properties.shortDescription}",
                mimeType:"text/html", 
                charset:"UTF-8"
        }
    }

}
```

`eureka配置`
```
server:
  port: ${port}

spring:
  resources:
    add-mappings: true
  application:
    name: bzy-eureka

eureka:
  environment: ${spring.profiles.active}
  instance:
    hostname: ${HOST_NAME}
    prefer-ip-address: false
    appname: ${spring.application.name}
    nonSecurePort: ${server.port}
    metadata-map:
          zone: ${spring.profiles.active}
  server:
    enable-self-preservation: true
      #5秒清理一次
    eviction-interval-timer-in-ms: 5000
  client:
        #如果需要集群rp，则需要打开自注册
    register-with-eureka: true
        #表示不去检索其他的Eureka Server获取注册信息，因为服务注册中心本身的职责就是维护服务实例，它也不需要去检索其他服务
    fetch-registry: false
    service-url:
        #对外暴露的地址
          defaultZone: ${EURAKE_HOST}

```

`微服务配置`
```
eureka:
    instance:
        hostname: bzy-daily
        prefer-ip-address: true
        instance-id: ${spring.application.name}:${spring.cloud.client.ip-address}:${server.port}
        nonSecurePort: ${server.port}
    client:
        service-url:
            defaultZone: ${EURAKE_HOST}

```
