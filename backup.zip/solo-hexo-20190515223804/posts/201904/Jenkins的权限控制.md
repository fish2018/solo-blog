title: Jenkins的权限控制
date: '2019-04-29 15:07:37'
updated: '2019-04-29 17:05:56'
tags: [devops]
permalink: /articles/2019/04/29/1556521657416.html
---
![](https://img.hacpai.com/bing/20190403.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### Jenkins的权限控制需要利用插件实现，主要分了三个步骤：
- 1、创建角色并分配基本权限
- 2、关联角色和项目，并分配权限
（这里只能通过关键词+通配符匹配，所以对Job的命名有要求，要加入一些关键词用于匹配）
- 3、注册用户，并关联用户和角色

#### 插件：
- Role-based Authorization Strategy 2.8.1

#### 安装后，点击 系统管理->全局安全配置->Role-Based Strategy
顺便把用户注册功能一起打开
![1.png](https://img.hacpai.com/file/2019/04/1-6dc69991.png)

#### 返回后再次点击 系统管理，会多出一个 Manage and Assign Roles，点击进去
![2.png](https://img.hacpai.com/file/2019/04/2-012a20fa.png)

#### 创建角色并分配基本权限
管理角色
![3.png](https://img.hacpai.com/file/2019/04/3-18c0ceb6.png)

添加角色，勾选基本权限，这里除了admin，其他角色只分配了read
![4.png](https://img.hacpai.com/file/2019/04/4-91d453fd.png)

管理角色和项目Job，这里只能通过Job名的关键词匹配，所以Job命名时要规划好
![5.png](https://img.hacpai.com/file/2019/04/5-1910c659.png)
最后点击save保存即可

分配角色
![6.png](https://img.hacpai.com/file/2019/04/6-7ee6dbf6.png)

分配全局角色
![7.png](https://img.hacpai.com/file/2019/04/7-5b82ab7b.png)

分配项目角色
![8.png](https://img.hacpai.com/file/2019/04/8-d1e663c2.png)

最后点击save保存即可

现在用不同用户登陆，看到的项目和权限也就不同了
![9.png](https://img.hacpai.com/file/2019/04/9-7304df3a.png)
![10.png](https://img.hacpai.com/file/2019/04/10-da1ba1e6.png)

