title: go使用代理加速下载模块
date: '2019-08-23 23:12:41'
updated: '2019-10-29 17:47:50'
tags: [go]
permalink: /articles/2019/08/23/1566573161661.html
---
### Go环境配置
安装包
```
https://dl.google.com/go/go1.13.3.linux-amd64.tar.gz
```
环境变量
```
export GO111MODULE=on
export GOROOT=/data/go 
export GOPATH=/data/apps
export PATH=$PATH:$GOROOT/bin:$GOPATH/bin
```

### Go第三方包代理设置 — GOPROXY
#### 常用代理：
[https://goproxy.cn](https://goproxy.cn/)
[https://goproxy.io](https://goproxy.io/)
[https://athens.azurefd.net](https://athens.azurefd.net/)
[https://mirrors.aliyun.com/goproxy/](https://mirrors.aliyun.com/goproxy/)

#### 使用方法：
命令行
```
export GOPROXY=https://goproxy.cn
```
goland
![image.png](https://img.hacpai.com/file/2019/08/image-0ffe81eb.png)

#### Go 语言全新依赖管理系统 Go Modules
Go Modules 基本使用
https://www.qikqiak.com/post/go-modules-usage/
Go Modules 详解
https://www.sulinehk.com/post/go-modules-details/
