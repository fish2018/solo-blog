title: nginx常用配置转换nginx-ingress配置方式
date: '2019-11-06 10:09:19'
updated: '2019-11-06 14:03:20'
tags: [devops]
permalink: /articles/2019/11/06/1573006159751.html
---
![](https://img.hacpai.com/bing/20180326.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

nginx很多强大的功能，在ingress中可以通过注解的方式来配置，比如认证、跨域等

对同一域名不同`path`反向代理到不同服务时，需要通过注解的方式rewrite，否则`path`后面的参数不会传递

### Nginx原始配置
```
server {
    listen 80;
    server_name spt-gw3.devopser.org;

    location /crm/ {
        proxy_pass http://spt-crm-service:8888/;
    }
    location /api/cbs/ {
        proxy_pass http://spt-cbs-service:8888/;
    }

}
```

### 使用nginx-ingress实现
方式一：
```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  annotations:
    # 关键在这条注解，将(.*)匹配的参数传递
    nginx.ingress.kubernetes.io/rewrite-target: /$1

  name: spt-gw3
  namespace: spt-dev
spec:
  rules:
  - host: spt-gw3.devopser.org
    http:
      paths:
      - backend:
          serviceName: spt-crm-service
          servicePort: 8888
        # 这里使用(.*)匹配后面参数
        path: /crm/(.*)
      - backend:
          serviceName: spt-cbs-service
          servicePort: 8888
        path: /api/cbs/(.*)
```
方式二：
```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  annotations:
    # 关键在这条注解，将(.*)匹配的参数传递
    nginx.ingress.kubernetes.io/configuration-snippet: |
      rewrite /crm/(.*)  /crm/$1 break;
      rewrite /api/cbs/(.*)  /$1 break;

  name: spt-gw3
  namespace: spt-dev
spec:
  rules:
  - host: spt-gw3.devopser.org
    http:
      paths:
      - backend:
          serviceName: spt-crm-service
          servicePort: 8888
        # 这里不再使用/(.*)
        path: /crm
      - backend:
          serviceName: spt-cbs-service
          servicePort: 8888
        # 这里不再使用/(.*)
        path: /api/cbs
```

#### 更多用法参考文档
https://github.com/kubernetes/ingress-nginx/blob/master/docs/user-guide/nginx-configuration/annotations.md

https://docs.giantswarm.io/guides/advanced-ingress-configuration/
