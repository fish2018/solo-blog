title: 使用kubebuilder自定义CRD资源和Controller
date: '2019-11-04 20:24:27'
updated: '2019-11-04 20:39:38'
tags: [devops, go]
permalink: /articles/2019/11/04/1572870267705.html
---
![](https://img.hacpai.com/bing/20180605.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 安装kustomize
kustomize在1.14+的kubectl中被集成，但是kubebuilder生成的项目Makefile用的还是kustomize命令

下载二进制文件安装
```
https://github.com/kubernetes-sigs/kustomize/releases/tag/kustomize%2Fv3.3.0
```
mac可以直接
```
brew install kustomize
```

### 二进制安装kubebuilder
```
os=$(go env GOOS)
arch=$(go env GOARCH)

# download kubebuilder and extract it to tmp
curl -sL https://go.kubebuilder.io/dl/2.0.1/${os}/${arch} | tar -xz -C /tmp/

# move to a long-term location and put it on your path
# (you'll need to set the KUBEBUILDER_ASSETS env var if you put it somewhere else)
sudo mv /tmp/kubebuilder_2.0.1_${os}_${arch} /usr/local/kubebuilder
export PATH=$PATH:/usr/local/kubebuilder/bin
```
### 创建项目
```
mkdir $GOPATH/src/example
cd $GOPATH/src/example
kubebuilder init --domain my.com
```
### 创建api
```
kubebuilder create api --group webapp --version v1 --kind Guestbook
```
### 安装CRDs到集群
```
make install
```
### 本地前台运行controller
```
make run
```
### 部署自定义资源的实例
```
kubectl apply -f config/samples/
```
### 修改Dockefile
```
cp -a ~/.kube kube
```
vi `Dockerfile`
```
FROM golang:1.12.5 as builder
WORKDIR /example
COPY go.mod go.mod
COPY go.sum go.sum
RUN rm -rf $GOPATH/go.mod && export GOPROXY=https://goproxy.cn &&  go mod download
COPY main.go main.go
COPY api/ api/
COPY controllers/ controllers/
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 GO111MODULE=on go build -a -o manager main.go
FROM gcr.azk8s.cn/distroless/static:nonroot
WORKDIR /
COPY kube /root/.kube
COPY --from=builder /example/manager .
#USER nonroot:nonroot
ENTRYPOINT ["/manager"]
```
### 构建/推送镜像
```
make docker-build docker-push IMG=<some-registry>/<project-name>:tag
```
### 部署到集群
```
make deploy IMG=<some-registry>/<project-name>:tag
```
