title: configmap热更新后自动重启pods
date: '2019-08-21 15:29:31'
updated: '2019-08-21 15:29:31'
tags: [devops]
permalink: /articles/2019/08/21/1566372571579.html
---
项目：https://github.com/stakater/Reloader
### 方式一：默认部署到default名称空间
```
wget https://raw.githubusercontent.com/stakater/Reloader/master/deployments/kubernetes/reloader.yaml
sed -i 's#RELEASE-NAME#config#g' reloader.yaml
kubectl apply -f reloader.yaml
```
### 方式二: 修改到kube-system名称空间
`reloader.yaml`
```
---
# Source: reloader/templates/role.yaml


---
# Source: reloader/templates/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  namespace: kube-system
  labels:
    app: config-reloader
    chart: "reloader-v0.0.39"
    release: "config"
    heritage: "Tiller"
    group: com.stakater.platform
    provider: stakater
    version: v0.0.39
    
  name: config-reloader
spec:
  replicas: 1
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: config-reloader
      release: "config"
  template:
    metadata:
      namespace: kube-system
      labels:
        app: config-reloader
        chart: "reloader-v0.0.39"
        release: "config"
        heritage: "Tiller"
        group: com.stakater.platform
        provider: stakater
        version: v0.0.39
        
    spec:
      containers:
      - env:
        image: "stakater/reloader:v0.0.39"
        imagePullPolicy: IfNotPresent
        name: config-reloader
        args:
      serviceAccountName: reloader

---
# Source: reloader/templates/clusterrole.yaml

apiVersion: rbac.authorization.k8s.io/v1beta1
kind: ClusterRole
metadata:
  labels:
    app: config-reloader
    chart: "reloader-v0.0.39"
    release: "config"
    heritage: "Tiller"
  name: config-reloader-role
  namespace: kube-system
rules:
  - apiGroups:
      - ""
    resources:
      - secrets
      - configmaps
    verbs:
      - list
      - get
      - watch
  - apiGroups:
      - "apps"
    resources:
      - deployments
      - daemonsets
      - statefulsets
    verbs:
      - list
      - get
      - update
      - patch
  - apiGroups:
      - "extensions"
    resources:
      - deployments
      - daemonsets
    verbs:
      - list
      - get
      - update
      - patch

---
# Source: reloader/templates/rolebinding.yaml


---
# Source: reloader/templates/clusterrolebinding.yaml

apiVersion: rbac.authorization.k8s.io/v1beta1
kind: ClusterRoleBinding
metadata:
  labels:
    app: config-reloader
    chart: "reloader-v0.0.39"
    release: "config"
    heritage: "Tiller"
  name: config-reloader-role-binding
  namespace: kube-system
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: config-reloader-role
subjects:
  - kind: ServiceAccount
    name: reloader
    namespace: kube-system

---
# Source: reloader/templates/serviceaccount.yaml

apiVersion: v1
kind: ServiceAccount
metadata:
  namespace: kube-system
  labels:
    app: config-reloader
    chart: "reloader-v0.0.39"
    release: "config"
    heritage: "Tiller"
  name: reloader
```
### 使用方法
如果某deployment需要随着configmap的更新而自动重启pods
只需要添加注释`reloader.stakater.com/auto: "true"`即可：
```
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {APP_NAME}-deployment
  annotations:
    reloader.stakater.com/auto: "true"
... ...
```