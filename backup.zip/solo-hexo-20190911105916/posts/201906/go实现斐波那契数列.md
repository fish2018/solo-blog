title: go实现斐波那契数列
date: '2019-06-16 12:10:42'
updated: '2019-06-16 12:13:08'
tags: [go]
permalink: /articles/2019/06/16/1560658242103.html
---
flag获取命令行参数，指定数值
chan和select结合实现斐波那契数列

```
package main

import (
	"flag"
	"fmt"
)

func Fib(ch chan<- int, quit <-chan bool) {
	x, y := 1, 1
	for {
		select {
		case ch <- x:
			x, y = y, x
			y = x + y
		case <-quit:
			return
		}
	}
}

func main() {
	var num int
	flag.IntVar(&num, "n", 0, "the number if fibonacci")
	flag.Parse()

	ch := make(chan int)
	quit := make(chan bool)

	go func() {
		fmt.Printf("Fibonacci of %d is :\n",num)
		for i := 0; i < num; i++ {
			n := <-ch
			fmt.Printf("%d ", n)
		}
		fmt.Println()
		quit <- true
	}()

	Fib(ch, quit)

}

```
