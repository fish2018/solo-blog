title: 精简jdk基础镜像构建
date: '2019-07-05 15:23:35'
updated: '2019-07-05 15:31:42'
tags: [devops]
permalink: /articles/2019/07/05/1562311415579.html
---
将脚本文件、jdk-8u201-linux-x64.tar.gz和Dockerfile放到同一个目录，然后执行脚本即可

`Dockerfile`
```
FROM frolvlad/alpine-glibc:alpine-3.8

ENV JAVA_HOME="/usr/lib/jvm/default-jvm" \
    JRE_HOME="/usr/lib/jvm/default-jvm/jre" \
    PATH="/usr/lib/jvm/default-jvm/bin:$PATH"
ADD  jvm /usr/lib/jvm
RUN  ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime \ 
        && echo "Asia/Shanghai" > /etc/timezone
```

`build.sh`
```
WORK=`pwd`
JAVA_VERSION=8
yum install wget unzip -y
tar -xzf `ls *.tar.gz`
TMP=`ls -l |awk '/^d/ {print $NF}'`
wget --header "Cookie: oraclelicense=accept-securebackup-cookie;" \
        "http://download.oracle.com/otn-pub/java/jce/$JAVA_VERSION/jce_policy-$JAVA_VERSION.zip"
unzip -jo -d "$TMP/jre/lib/security" "jce_policy-$JAVA_VERSION.zip"
rm -rf  "$TMP/"*src.zip \
        "$TMP/lib/missioncontrol" \
        "$TMP/lib/visualvm" \
        "$TMP/lib/"*javafx* \
        "$TMP/jre/lib/plugin.jar" \
        "$TMP/jre/lib/ext/jfxrt.jar" \
        "$TMP/jre/bin/javaws" \
        "$TMP/jre/lib/javaws.jar" \
        "$TMP/jre/lib/desktop" \
        "$TMP/jre/plugin" \
        "$TMP/jre/lib/"deploy* \
        "$TMP/jre/lib/"*javafx* \
        "$TMP/jre/lib/"*jfx* \
        "$TMP/jre/lib/amd64/libdecora_sse.so" \
        "$TMP/jre/lib/amd64/"libprism_*.so \
        "$TMP/jre/lib/amd64/libfxplugins.so" \
        "$TMP/jre/lib/amd64/libglass.so" \
        "$TMP/jre/lib/amd64/libgstreamer-lite.so" \
        "$TMP/jre/lib/amd64/"libjavafx*.so \
        "$TMP/jre/lib/amd64/"libjfx*.so \
        "$TMP/jre/bin/jjs" \
        "$TMP/jre/bin/keytool" \
        "$TMP/jre/bin/orbd" \
        "$TMP/jre/bin/pack200" \
        "$TMP/jre/bin/policytool" \
        "$TMP/jre/bin/rmid" \
        "$TMP/jre/bin/rmiregistry" \
        "$TMP/jre/bin/servertool" \
        "$TMP/jre/bin/tnameserv" \
        "$TMP/jre/bin/unpack200" \
        "$TMP/jre/lib/ext/nashorn.jar" \
        "$TMP/jre/lib/jfr.jar" \
        "$TMP/jre/lib/jfr" \
        "$TMP/jre/lib/oblique-fonts" \
        "$TMP/jre/lib/security/README.txt" \
        "$WORK/jce_policy-$JAVA_VERSION.zip"
ln -s $TMP default-jvm
mkdir jvm && mv $TMP default-jvm jvm
mkdir $WORK/build
cp $WORK/Dockerfile $WORK/build
mv jvm $WORK/build
cd $WORK/build && docker build -t jdk$JAVA_VERSION .
rm -rf $WORK/build
```