title: http代理for Linux(docker镜像下载)
date: '2019-05-07 21:48:07'
updated: '2019-05-08 08:57:12'
tags: [devops]
permalink: /articles/2019/05/07/1557236887856.html
---
![](https://img.hacpai.com/bing/20181024.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

部署HTTP代理主要为了docker镜像下载，这里仅做基本配置，其他优化自行设置，主要还是看你的海外主机了。
建议还是使用国内或微软镜像仓库。

## 方式一：tinyproxy
安装tinyproxy
```
yum install tinyproxy
```
修改配置
```
Port 5555 //端口自定义,默认8888
#Allow 127.0.0.1 //允许任何主机访问就直接注释
```
启动服务
```
service tinyproxy start
```
测试
```
curl -x www.devopser.org:5555 google.com
```
## 方式二：squid
安装squid
```
yum -y install squid
```
编辑配置 
vi /etc/squid/squid.conf
```
acl all src 0.0.0.0/0.0.0.0
acl SSL_ports port 443
acl Safe_ports port 80
acl Safe_ports port 21
acl Safe_ports port 443
acl CONNECT method CONNECT
http_access allow all
http_port 5555 //端口自定义
visible_hostname proxy
```
启动squid服务
```
systemctl enable squid
systemctl start squid
```
## 方式三：ss+privoxy
部署ss
```
yum install python-pip
yum install libsodium
pip install shadowsocks
```
服务端配置
vi /etc/shadowsocks/config.json
```
{
    "server":"0.0.0.0",
    "server_port":988,
    "local_address":"127.0.0.1",
    "local_port":1080,
    "password":"5M57kg11c214qDmK",
    "timeout":300,
    "method":"chacha20",
    "fast_open":false
}
```
启动服务端
```
ssserver -c /etc/shadowsocks/config.json
```
客户端配置，根据服务端配置参数自行修改
vi /etc/shadowsocks/config.json
```
{
    "server":"141.98.213.163",
    "server_port":988,
    "local_address":"127.0.0.1",
    "local_port":1080,
    "password":"5M57kg11c214qDmK",
    "timeout":300,
    "method":"chacha20",
    "fast_open":false
}
```
启动客户端
```
sslocal -c /etc/shadowsocks/config.json
```
安装privoxy
```
yum install privoxy
```
修改配置
vi /etc/privoxy/config
```
listen-address 127.0.0.1:5555  // 去掉前面的注释符号，端口可以随便改，默认8118，配置代理http://127.0.0.1:5555
forward-socks5t / 127.0.0.1:1080 .  //去掉前面的注释符号，后面的1080端口要对应ss服务里面的配置
```
设置环境后启动privoxy
```
systemctl restart privoxy
```

## 配置docker使用http代理
vi /lib/systemd/system/docker.service
```
[Service]
Environment="HTTP_PROXY=http://www.devopser.org:5555"
Environment="HTTPS_PROXY=http://www.devopser.org:5555"
Environment="NO_PROXY=127.0.0.0/8,192.168.0.10/24"
```
重启docker
```
systemctl daemon-reload
systemctl restart docker
```
查看代理是否生效
```
systemctl show docker --property Environment
```
测试
```
docker pull quay.io/kubernetes-ingress-controller/nginx-ingress-controller:0.24.1
```