title: kubeadm升级k8s版本和更新证书
date: '2019-08-21 16:53:27'
updated: '2019-08-21 16:53:27'
tags: [devops]
permalink: /articles/2019/08/21/1566377607823.html
---
# 使用kubeadm升级k8s版本
### 需要用到kubeadm的config文件，如果之前没有保存，使用命令查询后保存kubeadm-config.yaml
```
kubeadm config view > kubeadm-config.yaml
```
### 查看版本
```
kubeadm version
```
### 然后更新kubeadm
因为 kubeadm upgrade plan 命令执行过程中会去 dl.k8s.io 获取版本信息，这个地址是需要科学方法才能访问的，所以我们可以先将 kubeadm 更新到目标版本，然后就可以查看到目标版本升级的一些信息了
```
yum makecache fast && yum install -y kubeadm kubectl kubelet
```
### 重启kubelet服务
```
systemctl daemon-reload && systemctl restart kubelet
```

### 执行 upgrade plan 命令查看是否可以升级
```
kubeadm upgrade plan

>
You can now apply the upgrade by executing the following command:

	kubeadm upgrade apply v1.15.2
```
### 可以先使用 dry-run 命令查看升级信息
```
kubeadm upgrade apply v1.15.2 --config kubeadm-config.yaml --dry-run
```
### 确认无误后就可以执行升级操作
```
kubeadm upgrade apply v1.15.2 --config kubeadm-config.yaml
```
### 用 kubectl 来查看下版本信息,确认Server端和Client端都已经是新版本了
```
kubectl version
```

# 使用kubeadm更新证书
```
# 查看证书过期时间
kubeadm alpha certs check-expiration
# 更新证书，每个节点都要执行
kubeadm alpha certs renew all
```