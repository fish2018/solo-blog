title: 部署helm
date: '2019-08-21 17:34:50'
updated: '2019-08-22 09:37:26'
tags: [devops]
permalink: /articles/2019/08/21/1566380090235.html
---
安装依赖
```
yum install -y socat
```
https://github.com/kubernetes/helm/releases 下载二进制包
```
wget https://get.helm.sh/helm-v2.14.3-linux-amd64.tar.gz
tar xf helm-v2.14.3-linux-amd64.tar.gz
mv linux-amd64/{helm,tiller} /usr/bin
```
初始化helm
```
helm init --upgrade -i registry.cn-hangzhou.aliyuncs.com/google_containers/tiller:v2.14.3 --stable-repo-url https://kubernetes.oss-cn-hangzhou.aliyuncs.com/charts
```
查看
```
kubectl get pod -n kube-system -l app=helm
```
vi helm-rbac.yaml 为Tiller创建一个ServiceAccount
```
apiVersion: v1
kind: ServiceAccount
metadata:
  name: tiller
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1beta1
kind: ClusterRoleBinding
metadata:
  name: tiller
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
  - kind: ServiceAccount
    name: tiller
    namespace: kube-system
```
```
kubectl apply -f helm-rbac.yaml
```

给 Tiller 打上一个 ServiceAccount 的补丁
```
kubectl patch deploy --namespace kube-system tiller-deploy -p '{"spec":{"template":{"spec":{"serviceAccount":"tiller"}}}}'
```

验证
```
helm create hello-helm
helm install ./hello-helm
export POD_NAME=$(kubectl get pods --namespace default -l "app=hello-helm,release=kilted-bobcat" -o jsonpath="{.items[0].metadata.name}")
kubectl port-forward $POD_NAME 8080:80
curl 127.0.0.1:8080
```