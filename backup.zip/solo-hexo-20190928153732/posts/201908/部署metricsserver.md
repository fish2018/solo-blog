title: 部署metrics-server
date: '2019-08-21 16:57:20'
updated: '2019-08-21 16:57:20'
tags: [devops]
permalink: /articles/2019/08/21/1566377840811.html
---
```
yum install git -y
git clone https://github.com/kubernetes-incubator/metrics-server.git
cd metrics-server/deploy/1.8+/
```
修改metrics-server-deployment.yaml 添加command，替换image，完整文件如下
```
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: metrics-server
  namespace: kube-system
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: metrics-server
  namespace: kube-system
  labels:
    k8s-app: metrics-server
spec:
  selector:
    matchLabels:
      k8s-app: metrics-server
  template:
    metadata:
      name: metrics-server
      labels:
        k8s-app: metrics-server
    spec:
      serviceAccountName: metrics-server
      volumes:
      # mount in tmp so we can safely use from-scratch images and/or read-only containers
      - name: tmp-dir
        emptyDir: {}
      containers:
      - name: metrics-server
        image: gcr.azk8s.cn/google_containers/metrics-server-amd64:v0.3.3
        command:
        - /metrics-server
        - --kubelet-insecure-tls
        - --kubelet-preferred-address-types=InternalIP
        imagePullPolicy: Always
        volumeMounts:
        - name: tmp-dir
          mountPath: /tmp
```
```
kubectl apply -f /root/metrics-server/deploy/1.8+/
kubectl -n kube-system get pods | grep metrics
kubectl get apiservice | grep metrics
[root@k8s03 deploy]# kubectl top nodes
NAME    CPU(cores)   CPU%   MEMORY(bytes)   MEMORY%   
k8s01   259m         12%    1287Mi          68%       
k8s02   215m         10%    1183Mi          62%       
k8s03   291m         14%    1207Mi          64% 
```
### 查看Metrics API数据
启动代理
```
kubectl proxy --port=8080
curl localhost:8080/apis/metrics.k8s.io/v1beta1
```

### 小技巧，git单独下载指定文件夹
```
mkdir work && cd work
git init
git remote add -f origin https://github.com/kubernetes-incubator/metrics-server.git
git config core.sparsecheckout true
echo deploy/1.8+ >> .git/info/sparse-checkout
git pull origin master
```