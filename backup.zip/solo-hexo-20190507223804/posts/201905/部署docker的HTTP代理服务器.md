title: 部署docker的HTTP代理服务器
date: '2019-05-07 21:48:07'
updated: '2019-05-07 22:25:23'
tags: [devops]
permalink: /articles/2019/05/07/1557236887856.html
---
![](https://img.hacpai.com/bing/20181024.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

这里仅做基本配置，其他优化自行设置，主要还是看你的海外主机了

安装squid
```
yum -y install squid
```
编辑配置 [squid设置账号密码](https://www.cnblogs.com/lixiaolun/p/7449017.html)
vi /etc/squid/squid.conf
```
acl all src 0.0.0.0/0.0.0.0
acl SSL_ports port 443
acl Safe_ports port 80
acl Safe_ports port 21
acl Safe_ports port 443
acl CONNECT method CONNECT
http_access allow all
http_port 3128
visible_hostname proxy
```
启动squid服务
```
systemctl enable squid
systemctl start squid
```
配置docker使用http代理
vi /lib/systemd/system/docker.service
```
[Service]
Environment="HTTP_PROXY=http://USER:PASS@www.devopser.org:3128"
Environment="HTTPS_PROXY=http://USER:PASS@www.devopser.org:3128"
Environment="NO_PROXY=127.0.0.0/8,192.168.0.10/24"
```
重启docker
```
systemctl daemon-reload
systemctl restart docker
```
查看代理是否生效
```
systemctl show docker --property Environment
```
测试
```
docker pull quay.io/kubernetes-ingress-controller/nginx-ingress-controller:0.24.1
```