title: 支持多应用的pms统一权限管理系统
date: '2019-09-05 14:00:09'
updated: '2019-09-07 10:41:31'
tags: [vue, flask, devops]
permalink: /articles/2019/09/05/1567663209232.html
---
项目地址：https://github.com/fish2018/pms-template

在线demo:
pms前端：www.seczh.com
pms后端：www.seczh.com:3344

对接应用前端：xxx
对接应用后端：xxx

## 背景
这个项目创建之初是由于我们开发了多个项目，需要对接SSO给其他部门使用，但是SSO只负责账号认证，并不负责权限分配，比如我们的发布系统，如果随便谁用SSO登录后就能发布生产环境应用，这就炸了。。。

这个版本的PMS是我从对接SSO的版本中解耦出来的，不再使用SSO的账号认证，转而使用PMS自己的一套账号密码验证，其实这只能是一个临时方案，我的思路是PMS要么和SSO做成一体化，要么对接SSO，要么对接LDAP，所以后面我考虑改成对接openldap的通用方案。

## 应用管理
添加需要接入的应用

![01.jpg](https://img.hacpai.com/file/2019/09/01-c4698d45.jpg)

应用列表

![02.jpg](https://img.hacpai.com/file/2019/09/02-2850ba2f.jpg)

### 添加需要约束的应用资源
应用资源列表

![04.jpg](https://img.hacpai.com/file/2019/09/04-db4573e2.jpg)

#### 资源类型分三种
![031.jpg](https://img.hacpai.com/file/2019/09/031-58d7aa1f.jpg)

url权限：对url地址的请求方法进行限制

![032.jpg](https://img.hacpai.com/file/2019/09/032-56eda848.jpg)

页面元素权限：前端根据其判断是否显示或禁用

![033.jpg](https://img.hacpai.com/file/2019/09/033-b2d98c53.jpg)

数据权限：数据库查询时根据其作为查询条件约束

![034.jpg](https://img.hacpai.com/file/2019/09/034-962b63e8.jpg)

这里添加一个url类型的资源：
![03.jpg](https://img.hacpai.com/file/2019/09/03-5a44011a.jpg)

### 应用菜单

菜单配置和路由信息保持一致，这里需要有一定的vue路由知识

![05.jpg](https://img.hacpai.com/file/2019/09/05-5070babf.jpg)

创建菜单

![051.jpg](https://img.hacpai.com/file/2019/09/051-81fd8cc2.jpg)

点击新建节点来添加节点

![052.jpg](https://img.hacpai.com/file/2019/09/052-64338c12.jpg)

设置菜单对应的路由属性

![053.jpg](https://img.hacpai.com/file/2019/09/053-d4fcf952.jpg)
![054.jpg](https://img.hacpai.com/file/2019/09/054-ec286174.jpg)

## 权限管理
### 资源权限
![06.jpg](https://img.hacpai.com/file/2019/09/06-1fea3862.jpg)

对之前创建的资源关联权限，对于url类型的资源权限就是http请求方法

![061.jpg](https://img.hacpai.com/file/2019/09/061-5a27754f.jpg)

### 菜单权限
![07.jpg](https://img.hacpai.com/file/2019/09/07-1cc3f5c4.jpg)

勾选菜单并命名，用于后续分配
![071.jpg](https://img.hacpai.com/file/2019/09/071-1c9ea840.jpg)
![072.jpg](https://img.hacpai.com/file/2019/09/072-49cdb4b3.jpg)

## 组织管理
![08.jpg](https://img.hacpai.com/file/2019/09/08-98ee941c.jpg)

为指定应用系统创建分组

![081.jpg](https://img.hacpai.com/file/2019/09/081-7cf83021.jpg)

给刚才创建的分组分配成员

![082.jpg](https://img.hacpai.com/file/2019/09/082-ff354ed5.jpg)

给刚才创建的分组分配资源权限

![083.jpg](https://img.hacpai.com/file/2019/09/083-f88633f7.jpg)

给刚才创建的分组分配菜单权限

![084.jpg](https://img.hacpai.com/file/2019/09/084-f70cec8d.jpg)

## 应用对接PMS
例子后续补充上来，应用对接一共有三个地方和pms有交互：
1、用户在登陆时会请求pms拿到一个token
2、以后每次需要鉴权时应用都会带着这个token去请求pms鉴权(实现一个装饰器，在需要鉴权的类中使用)
3、退出登录时和pms交互清除token。

## 演示
使用admin用户登录，拥有完整菜单，所有资源权限

![admin.jpg](https://img.hacpai.com/file/2019/09/admin-0f4bf07c.jpg)

使用guest用户登录，只用有部分菜单，应用操作的url被限制的请求方法
![guest.jpg](https://img.hacpai.com/file/2019/09/guest-7e71292e.jpg)

## 一些细节实现相关文章

[利用二进制位运算实现权限控制](http://www.devopser.org/articles/2019/04/24/1556061973923.html)

[Tree组件数据结构相互转换 flat <=> nested](http://www.devopser.org/articles/2019/04/29/1556524023536.html)

[根据用户权限动态生成菜单路由](http://www.devopser.org/articles/2019/04/29/1556524856420.html)
