title: jenkins发布预览微信小程序(windows_slave)
date: '2019-05-31 14:56:57'
updated: '2019-05-31 16:42:03'
tags: [devops]
permalink: /articles/2019/05/31/1559285817839.html
---
![](https://img.hacpai.com/bing/20180730.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

[微信小程序](https://mp.weixin.qq.com)开发工具目前只支持mac和windows，所以jenkins的slave也只能使用这两种系统，这里我已windows为例。构建批处理仅作了功能实现，更多的判断逻辑自行添加。

微信工具提供了[客户端](https://developers.weixin.qq.com/miniprogram/dev/devtools/cli.html)和[HTTP服务](https://developers.weixin.qq.com/miniprogram/dev/devtools/http.html)两种方式给外部调用，这里以http方式为例

## jenkins添加windows端slave
### 修改全局安全设置
”JNLP代理协议的TCP端口“ 配置成 ”随机选取“，点开”代理协议...“，勾选“Java Web Start Agent Protocol/4(TLS加密)”。我这里选择固定端口是因为在阿里云做了端口限制，只放开指定端口
![image.png](https://img.hacpai.com/file/2019/05/image-4464b36b.png)
找到“隐藏的安全警告”，将“Enable Agent → Master Access Control”的复选框打勾
![image.png](https://img.hacpai.com/file/2019/05/image-307b74a7.png)
### 添加slave节点：系统管理->节点管理->新建节点
![image.png](https://img.hacpai.com/file/2019/05/image-5b38a122.png)
![image.png](https://img.hacpai.com/file/2019/05/image-4046aed1.png)
点击launch按钮下载slave-agent.jnlp文件，点击slave.jar下载该jar包，并复制到slave机器的jenkins目录
![1.png](https://img.hacpai.com/file/2019/05/1-3f62cc5c.png)
运行slave-agent.jnlp
![2.png](https://img.hacpai.com/file/2019/05/2-784efe99.png)
快捷键win+r输入services.msc，找到jenkins-agent修改配置
我这里使用了管理员账户，也可以使用上面的本地系统账户，但要记得勾选允许服务与桌面交互
![image.png](https://img.hacpai.com/file/2019/05/image-58916ea9.png)

### 安装依赖工具
想要运行slave，windows节点需要先安装[java](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)，构建环节还会用到一些其他工具，如[git](https://git-scm.com/downloads)、[curl](https://curl.haxx.se/download.html)直接下载安装，记得要设置对应的环境变量

在slave节点配置中配置环境变量，直接把windows机器的path环境变量拷贝过来即可
这里在path变量补充一个"C:\Windows\SysWOW64\;",否则一些内置命令也会无法调用
![image.png](https://img.hacpai.com/file/2019/05/image-816a4317.png)
![image.png](https://img.hacpai.com/file/2019/05/image-bb1c0035.png)
![image.png](https://img.hacpai.com/file/2019/05/image-f7e52966.png)

安装[微信开发者工具](https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html)，然后设置计划任务自动运行，以便提供http服务
![image.png](https://img.hacpai.com/file/2019/05/image-ac2634d2.png)
名称：mp_ide
触发器：计算机启动时
操作：启动程序
![image.png](https://img.hacpai.com/file/2019/05/image-cbdc474c.png)
![image.png](https://img.hacpai.com/file/2019/05/image-a6a82c8a.png)
![image.png](https://img.hacpai.com/file/2019/05/image-530b6e4d.png)
如果不重启，记得自己手动启动一次

## jenkins配置
### 安装插件：
[description setter plugin](http://wiki.jenkins-ci.org/display/JENKINS/Description+Setter+Plugin)
[Git Parameter Plug-In](http://wiki.jenkins-ci.org/display/JENKINS/Git+Parameter+Plugin)

### 修改全局安全配置：
![image.png](https://img.hacpai.com/file/2019/05/image-11097d01.png)

### 创建自由风格任务
![image.png](https://img.hacpai.com/file/2019/05/image-4ef99cff.png)

### 勾选参数化构建
#### 添加Git Parameter
![image.png](https://img.hacpai.com/file/2019/05/image-1301e66c.png)
![image.png](https://img.hacpai.com/file/2019/05/image-aebf2719.png)

### 添加2个文本参数
![image.png](https://img.hacpai.com/file/2019/05/image-84b077df.png)
![image.png](https://img.hacpai.com/file/2019/05/image-90a8a144.png)

### 限制项目的运行节点在windows-slave
![image.png](https://img.hacpai.com/file/2019/05/image-70760d19.png)

### 配置git地址
![image.png](https://img.hacpai.com/file/2019/05/image-2932733b.png)

### 构建环节
#### 第一次增加批处理
![image.png](https://img.hacpai.com/file/2019/05/image-4a601656.png)
```
:: 获取服务端口
set /p PORT=<"C:\Users\test-ops\AppData\Local\微信开发者工具\User Data\Default\.ide"
echo "微信开发者工具运行在%PORT%端口"

:: 获取状态码判断服务是否启动成功
curl -sL -w %%{http_code} http://127.0.0.1:%PORT%/open

:: 获取登录二维码
curl http://127.0.0.1:%PORT%/login?format=base64 > qrcode.txt
python "D:\jenkins\base64tojepg.py" qrcode.txt qrcode.jpg
echo [QRCode generated succeed]%BUILD_NUMBER%
```
python脚本：base64tojepg.py
```
import os,base64,sys 

if len(sys.argv) == 3:
    inputFileName=sys.argv[1]
    outputFileName=sys.argv[2]
    allstr=open(inputFileName).read()
    idx=allstr.find(',')
    bstr=allstr[idx+1:]
    imgdata=base64.b64decode(bstr)
    file=open(outputFileName,'wb')
    file.write(imgdata)
    file.close()
else:
    print('Useage: python base64tojpeg.py inputFileName outputFileName')
```
#### 第一次添加 build description用于显示登录二维码
![image.png](https://img.hacpai.com/file/2019/05/image-74f902df.png)
![image.png](https://img.hacpai.com/file/2019/05/image-06e2cde7.png)
Regular expression
```
\[QRCode generated succeed\](.*)
```
Description
```
<img src= "${JOB_URL}ws/qrcode.jpg?t=_\1" height= "200" width= "200" /><br/>微信扫码登录
```
#### 第二次添加批处理
```
:: 延迟15秒，等待扫码登陆，否则无法进行代码上传
@ping 127.0.0.1 -n 15 >nul

:: 获取服务端口
set /p PORT=<"C:\Users\test-ops\AppData\Local\微信开发者工具\User Data\Default\.ide"
echo "微信开发者工具运行在%PORT%端口"

:: 获取预览二维码
del /f /s /q qrcode.txt qrcode.jpg
curl -o preview.jpg http://127.0.0.1:%PORT%/preview?projectpath=%WORKSPACE%
echo [QRCode preview generated succeed]%BUILD_NUMBER%

:: 上传代码
for /f "delims=" %%i in ('python D:\jenkins\urlencode.py %upload_desc%') do set desc=%%i
curl "http://127.0.0.1:%PORT%/upload?projectpath=D:\mp&version=%upload_version%&desc=%desc%"
echo "上传成功！请到微信小程序后台设置体验版或提交审核！"
```
python脚本：urlencode.py
```
from urllib.parse import quote
import sys

data = sys.argv[1]
print(quote(data))
```
#### 第二次添加 build description用于显示开发预览二维码
Regular expression
```
\[QRCode preview generated succeed\](.*)
```
Description
```
<img src= "${JOB_URL}ws/preview.jpg?t=_\1" height= "200" width= "200" /><br/>微信扫码预览
```

## 执行构建
构建过程中，可以直接显示二维码
这个是用来登录小程序开发工具的，如果不登录无法进行代码上传
![image.png](https://img.hacpai.com/file/2019/05/image-c3389676.png)
这个是预览小程序的二维码，由于预览要求源码目录大小不能超过2M，所以在生成预览二维码前，先把之前的登录二维码相关文件删除，尽可能保证源码目录大小
![image.png](https://img.hacpai.com/file/2019/05/image-55482fba.png)
