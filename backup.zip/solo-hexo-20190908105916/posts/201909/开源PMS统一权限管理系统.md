title: 开源PMS统一权限管理系统
date: '2019-09-05 14:00:09'
updated: '2019-09-08 09:00:44'
tags: [vue, flask, devops]
permalink: /articles/2019/09/05/1567663209232.html
---
![](https://img.hacpai.com/bing/20190906.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

项目地址：https://github.com/fish2018/openpms.git

## 一、背景
这个项目创建之初是由于我们开发了多个项目，需要对接SSO给其他部门使用，但是SSO只负责账号认证，并不负责权限分配，比如我们的发布系统，如果随便谁用SSO登录后就能发布生产环境应用，这就炸了。。。

这个版本的PMS是我从对接SSO的版本中解耦出来的，不再使用SSO的账号认证，转而使用PMS自己的一套账号密码验证，其实这只能是一个临时方案，我的思路是PMS要么和SSO做成一体化，要么对接SSO，要么对接LDAP，所以后面我考虑改成对接openldap的通用方案。

## 二、在线demo演示
pms前端：www.seczh.com
pms后端：www.seczh.com:3344
账号：admin/admin test/test

对接应用前端：www.devopser.org:81
对接应用后端：www.devopser.org:7788
账号：test/test

### 演示菜单的权限控制
admin登录PMS系统，管理用户组权限显示完整菜单

![docking08.jpg](https://img.hacpai.com/file/2019/09/docking08-4d23f558.jpg)

test登录PMS系统，访客用户组权限只显示部分菜单

![docking09.jpg](https://img.hacpai.com/file/2019/09/docking09-6628c707.jpg)


### 演示对url和页面元素类型资源的权限控制
test登录PMS系统

![docking05.jpg](https://img.hacpai.com/file/2019/09/docking05-6c6ba9a7.jpg)、

对按钮添加禁止权限，同时不添加url操作权限

![docking06.jpg](https://img.hacpai.com/file/2019/09/docking06-53049717.jpg)

test登录对接应用系统

![docking04.jpg](https://img.hacpai.com/file/2019/09/docking04-2dbfc27d.jpg)


![docking01.jpg](https://img.hacpai.com/file/2019/09/docking01-5564758d.jpg)

点击测试，按钮被隐藏掉，并提示对api的url请求无权限，

![docking03.jpg](https://img.hacpai.com/file/2019/09/docking03-70918fd7.jpg)

test登录PMS系统，添加url权限

![docking07.jpg](https://img.hacpai.com/file/2019/09/docking07-327650ef.jpg)

test登录对接应用系统，点击测试得到请求返回值

![docking02.jpg](https://img.hacpai.com/file/2019/09/docking02-352efa37.jpg)


## 三、PMS权限管理流程：
1、添加应用：要对接PMS的应用，记住APPID
2、创建该应用的用户组：用于分配成员、菜单和权限。比如管理员组admin，访客组guest
3、创建该应用的菜单资源：完整的菜单树，用于后续勾选分配
4、创建该应用的菜单权限：菜单权限有自己的名称，用于后续分配。比如"管理员菜单"显示所有菜单，"访客菜单"只显示部分菜单
5、分配菜单：组管理中分配菜单，选择菜单权限名称。比如给admin组分配"管理员菜单"，给guest组分配"访客菜单"
6、创建该应用的资源：要被约束的资源对象，有url、页面元素和数据三种类型的资源
7、创建该资源的操作权限：资源操作权限有自己的名称，用于后续分配。针对该资源能够进行的操作。比如对url类型资源限制请求方法只能get不能post；页面元素类型资源如按钮禁用或隐藏；数据权限比较难以通用的方案控制，所以这里依据配置的值作为一个sql查询的过滤条件进行约束
8、分配资源权限：组管理中分配权限，选择资源操作权限名称。比如给guest组分配"隐藏删除按钮"的页面元素类型资源的操作权限。

## 四、界面操作说明
### 1、应用管理
#### 1.1 添加需要接入的应用

![use01.jpg](https://img.hacpai.com/file/2019/09/use01-ebe43d7d.jpg)
![use02.jpg](https://img.hacpai.com/file/2019/09/use02-03155199.jpg)

#### 1.2 添加需要约束的应用资源
应用资源列表

![04.jpg](https://img.hacpai.com/file/2019/09/04-db4573e2.jpg)

##### 1.2.1 资源类型分三种
![use06.jpg](https://img.hacpai.com/file/2019/09/use06-20c89545.jpg)

- url权限：对url地址的请求方法进行限制

![use07.jpg](https://img.hacpai.com/file/2019/09/use07-67568b85.jpg)

- 页面元素权限：前端根据其判断是否显示或禁用

![use08.jpg](https://img.hacpai.com/file/2019/09/use08-6860a018.jpg)

- 数据权限：数据库查询时根据其作为查询条件约束

![use09.jpg](https://img.hacpai.com/file/2019/09/use09-abb7d52f.jpg)

这里添加一个url类型的资源：
![use10.jpg](https://img.hacpai.com/file/2019/09/use10-c0e0e986.jpg)

#### 1.2.2 应用菜单

菜单配置和路由信息保持一致，这里需要有一定的vue路由知识

![05.jpg](https://img.hacpai.com/file/2019/09/05-5070babf.jpg)

创建菜单

![use11.jpg](https://img.hacpai.com/file/2019/09/use11-d6c481d8.jpg)

点击新建节点来添加节点

![use12.jpg](https://img.hacpai.com/file/2019/09/use12-08fef5e3.jpg)

设置菜单对应的路由属性
查看前端项目路由信息
![use15.jpg](https://img.hacpai.com/file/2019/09/use15-6d861729.jpg)
对应vue的路由信息填写即可
![use13.jpg](https://img.hacpai.com/file/2019/09/use13-4e2310ad.jpg)
![use14.jpg](https://img.hacpai.com/file/2019/09/use14-8a276b9b.jpg)


### 2、权限管理
#### 2.1 资源权限
![06.jpg](https://img.hacpai.com/file/2019/09/06-1fea3862.jpg)

对于url类型资源的操作权限就是约束请求方法

![use16.jpg](https://img.hacpai.com/file/2019/09/use16-9e2aba90.jpg)

对于页面元素类型资源的操作权限就是禁止

![use17.jpg](https://img.hacpai.com/file/2019/09/use17-fa25d59d.jpg)

#### 2.2 菜单权限
![image.png](https://img.hacpai.com/file/2019/09/image-9e769d1a.png)

点击"+"按钮创建菜单权限，勾选菜单并命名，用于后续分配
![use19.jpg](https://img.hacpai.com/file/2019/09/use19-63ca84bd.jpg)
![use20.jpg](https://img.hacpai.com/file/2019/09/use20-ec9cbef0.jpg)

### 3、组织管理
![use21.jpg](https://img.hacpai.com/file/2019/09/use21-f089933d.jpg)

点击"+"按钮为指定应用系统创建分组

![use22.jpg](https://img.hacpai.com/file/2019/09/use22-d4b8d8a7.jpg)

给刚才创建的分组分配成员

![use23.jpg](https://img.hacpai.com/file/2019/09/use23-b602ab20.jpg)


给刚才创建的分组分配资源权限

![use24.jpg](https://img.hacpai.com/file/2019/09/use24-f2a700cb.jpg)

给刚才创建的分组分配菜单权限

![use25.jpg](https://img.hacpai.com/file/2019/09/use25-5b20e05d.jpg)

## 五、应用对接PMS说明(待补充)
对接文档后续补充上来，也可以直接看git上demo的实现，应用对接一共有三个地方和pms有交互：
1、用户在登陆时会请求pms拿到一个token
2、以后每次需要鉴权时应用都会带着这个token去请求pms鉴权(实现一个装饰器，在需要鉴权的类中使用)
3、退出登录时和pms交互清除token。


## 一些细节实现相关文章

[利用二进制位运算实现权限控制](http://www.devopser.org/articles/2019/04/24/1556061973923.html)

[Tree组件数据结构相互转换 flat <=> nested](http://www.devopser.org/articles/2019/04/29/1556524023536.html)

[根据用户权限动态生成菜单路由](http://www.devopser.org/articles/2019/04/29/1556524856420.html)
