title: flask项目部署
date: '2019-04-29 14:58:57'
updated: '2019-04-29 15:05:28'
tags: [flask]
permalink: /articles/2019/04/29/1556521137375.html
---
![](https://img.hacpai.com/bing/20180919.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

| --- | --- |
| python3 |python环境  |
| flask | python的服务器框架 |
|gunicorn|WSGI的容器|
|supervisor|进程管理工具|
|nginx|高性能的 web 服务器|
|gevent|协程模块|

一、编译安装python3
```
wget https://www.python.org/ftp/python/3.6.1/Python-3.6.1.tar.xz
tar xf Python-3.6.1.tar.xz
cd Python-3.6.1
./configure --prefix=/usr/local/python3
make && make install
ln -s /usr/local/python3/bin/python3 /usr/bin/python3
```
二、创建虚拟环境
```
创建虚拟环境
python3 -m venv venv
# 激活虚拟环境
source venv/bin/activate
# 退出虚拟环境
deactivate
```
三、安装gunicorn
```
pip3 install gunicorn
```
四、安装gevent
```
pip3 install gevent
```
五、安装项目依赖
```
pip3 install -r requirements.txt
```
六、修改Nginx配置
```
server {
    listen 7777;
    server_name _;
    access_log /usr/local/work/exporter/log/nginx.log;
    error_log /usr/local/work/exporter/log/nginx.err;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP   $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
    location /metrics {
        proxy_pass http://127.0.0.1:8000/metrics;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP   $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```
重载Nginx配置
```
service nginx reload
systemctl reload nginx
```
七、安装配置supervisor
```
# 安装supervisor
pip install supervisor
# 生成默认配置
echo_supervisord_conf > /etc/supervisord.conf  # 生成 supervisor 默认配置文件
```
修改 supervisor 配置文件，添加 gunicorn 进程管理
vi /etc/supervisord.conf
```
[program:exporter]
command=/usr/local/work/exporter/venv/bin/gunicorn -w1 -b127.0.0.1:8000 -k gevent run:app  ; supervisor启动命令
directory=/usr/local/work/exporter  ; 项目的文件夹路径
startsecs=0  ; 启动时间
stopwaitsecs=0  ; 终止等待时间
autostart=false  ; 是否自动启动
autorestart=false  ; 是否自动重启
stdout_logfile=/usr/local/work/exporter/log/gunicorn.log  ; log 日志
tderr_logfile=/usr/local/work/exporter/log/gunicorn.err  ; 错误日志
environment = PYTHONPATH="$PYTHONPATH:/usr/loacl/sunmi/fds_exporter/venv/lib64"  ; 指定依赖包路径
```
gunicorn参数解释：
```
-w: 指定worker的数量
-b：指定绑定的地址和端口号
-k: 指定worker-class模式，默认为sync，这里用gevent使之变为异步协程，提高性能。
run就是run.py的文件名
app是实例名
```
使用 supervsior 启动 gunicorn
```
supervisord -c /etc/supervisord.conf
supervisorctl start exporter
```
supervisor的基本使用命令
```
supervisorctl status       # 查询进程状态
supervisorctl stop node    # 关闭 [program:node] 的进程
supervisorctl start node   # 启动 [program:node] 的进程
supervisorctl restart node # 重启 [program:node] 的进程
supervisorctl stop all     # 关闭所有进程
supervisorctl start all    # 启动所有进程
supervisorctl reload       # 重新读取配置文件,读取有更新（增加）的配置文件，不会启动新添加的程序
supervisorctl update       # 重启配置文件修改过的程序
```
supervisor 还有一个web的管理界面，可以激活。更改下配置
```
[inet_http_server]         ; inet (TCP) server disabled by default
port=127.0.0.1:9001        ; (ip_address:port specifier, *:port for all iface)
username=user              ; (default is no username (open server))
password=123               ; (default is no password (open server))

[supervisorctl]
serverurl=unix:///tmp/supervisor.sock ; use a unix:// URL  for a unix socket
serverurl=http://127.0.0.1:9001 ; use an http:// url to specify an inet socket
username=user              ; should be same as http_username if set
password=123                ; should be same as http_password if set
;prompt=mysupervisor         ; cmd line prompt (default "supervisor")
;history_file=~/.sc_history  ; use readline history if available
```
访问 http://127.0.0.1:9001 可以得到 supervisor的web管理界面
