title: Npm私库Nexus部署
date: '2019-04-29 15:20:34'
updated: '2019-04-29 17:05:33'
tags: [devops]
permalink: /articles/2019/04/29/1556522434049.html
---
![](https://img.hacpai.com/bing/20180215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 环境：
- centos 7.4
- node.js v8.11.3
- jdk-8u171 1.8.0_171
- nexus 3.12.1-01

### 一、部署JDK
#### 使用rpm包方式
```
rpm -ivh jdk-8u171-linux-x64.rpm
```
#### 配置JDK环境变量
vi /etc/profile
```
export JAVA_HOME=/usr/java/jdk1.8.0_171-amd64
export JRE_HOME=$JAVA_HOME/jre
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib/rt.jar
export PATH=$PATH:$JAVA_HOME/bin
```

加载环境变量
```
source /etc/profile
```

命令行执行`java -version`验证，显示版本说明成功
![1.png](https://img.hacpai.com/file/2019/04/1-9a125795.png)

### 二、部署node.js
#### 使用二进制包方式
创建/data目录，稍后用于存放node.js
```
mkdir  /data
```

下载、解压node.js二进制包，拷贝到/data目录并重命名
```
wget https://nodejs.org/dist/v8.11.3/node-v8.11.3-linux-x64.tar.xz
tar xf node-v8.11.3-linux-x64.tar.xz
cp -a node-v8.11.3-linux-x64 /data/node-v8.11.3
```

配置node.js环境变量
vi /etc/profile
```
export NODE_HOME=/data/node-v8.11.3
export PATH=$NODE_HOME/bin:$PATH
```

加载环境变量
```
source /etc/profile
```

命令行执行`node -v`验证，显示版本说明成功
![2.png](https://img.hacpai.com/file/2019/04/2-4c1aa2fa.png)

### 三、部署nexus
下载地址：[nexus-3.12.1-01-unix.tar.gz](https://www.sonatype.com/download-oss-sonatype?hsCtaTracking=10655413-f621-4c62-be46-df84cf6b6b90|79f798b3-f0df-4370-b569-0eda6e14390e "nexus-3.12.1-01-unix.tar.gz")

创建/data/npm_repository目录，稍后用于存放nexus
```
mkdir /data/npm_repository
```

解压nexus二进制包，移动到/data/npm_repository目录
```
tar xf nexus-3.12.1-01-unix.tar.gz
mv nexus-3.12.1-01 sonatype-work /data/npm_repository/
```

配置环境变量
vi /etc/profile
```
export RUN_AS_USER=root
```

加载环境变量
```
source /etc/profile
```

编写nexus重启脚本
vi restart-NpmRepository.sh
```
#!/bin/bash
/data/npm_repository/nexus-3.12.1-01/bin/nexus restart
```

执行脚本启动nexus，默认端口8081，默认账号:admin 密码:admin123
```
sh restart-NpmRepository.sh
```

### 四、配置nexus npm仓库
浏览器访问 http://47.96.233.16:8081, 登陆默认账号密码
点击小齿轮进入配置界面
![3.png](https://img.hacpai.com/file/2019/04/3-74fc93b3.png)

#### 设置认证
点击Security->Realms，将npm Bearer Token Realm添加到右边，点击save保存
![4.png](https://img.hacpai.com/file/2019/04/4-d1132fa0.png)

#### 添加npm仓库
npm仓库分三种：
- Proxying npm Registries
npm代理库，从共有库下载依赖包后会缓存一份在本库，以后再下载时，直接从代理库下载

- Private npm Registries
npm私库，用于上传自己的包及第三方包

- Grouping npm Registries
将多个代理库、私库统一为一个仓库组，这样既可以访问公有库，又可以访问私库

点击Repository->repositoris->create repository
![5.png](https://img.hacpai.com/file/2019/04/5-5e466286.png)
![6.png](https://img.hacpai.com/file/2019/04/6-af3cad3d.png)

创建npm代理库,点击npm(proxy)，设置如下，最后点击Create repository
![7.png](https://img.hacpai.com/file/2019/04/7-12894eeb.png)

创建npm私库，点击npm(hosted)，设置如下，最后点击Create repository
![8.png](https://img.hacpai.com/file/2019/04/8-78558c71.png)

创建npm库组，点击npm(group)，设置如下，把刚才创建的npm代理库、npm私库添加到右边，最后点击save保存
![10.png](https://img.hacpai.com/file/2019/04/10-5b94c2c1.png)
![11.png](https://img.hacpai.com/file/2019/04/11-39afed75.png)

### 配置npm使用nexus仓库
####设置npm使用npm库组
```
npm config set registry http://47.96.233.16:8081/repository/npm-group/
```
该命令会在当前用户的家目录下生成.npmrc文件,也可以手动编辑
[root@yunwei-test ~]# cat .npmrc
```
registry=http://47.96.233.16:8081/repository/npm-group/
```

#### 通过nexus安装包
安装一个包试试效果，可以看到地址是走的我们部署的nexus仓库
```
npm --loglevel info install react
```
![12.png](https://img.hacpai.com/file/2019/04/12-55ac6320.png)

#### 发布到npm私库
先创建一个nexus账号，稍后需要登陆使用,填写好资料后点击create local user
![13.png](https://img.hacpai.com/file/2019/04/13-4148040b.png)
![14.png](https://img.hacpai.com/file/2019/04/14-8f8e54c0.png)

使用Realm认证和登陆
```
npm login --registry=http://47.96.233.16:8081/repository/npm-hosted/
```
![15.png](https://img.hacpai.com/file/2019/04/15-0e9fc1c2.png)

发布前提在执行npm命令的目录下有package.json文件，可以`npm init`生成
官方文档建议在package.json中加入如下内容，实际测试不加也可以
```
"publishConfig" : {
  "registry" : "http://47.96.233.16:8081/repository/npm-hosted/"
},
```
执行发布
```
npm publish --registry=http://47.96.233.16:8081/repository/npm-hosted/
```
![16.png](https://img.hacpai.com/file/2019/04/16-bce6f09a.png)

#### 页面浏览npm仓库
npm代理库缓存的包
![17.png](https://img.hacpai.com/file/2019/04/17-e9f3d958.png)

npm私库自己上传的包
![18.png](https://img.hacpai.com/file/2019/04/18-ad0cf3ca.png)

#### 从nexus删除
```
npm deprecate --registry=http://47.96.233.16:8081/repository/npm-hosted/ mytest@1.0.0 ""
```