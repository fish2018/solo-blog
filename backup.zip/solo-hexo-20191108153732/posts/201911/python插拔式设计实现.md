title: python插拔式设计实现
date: '2019-11-08 10:15:36'
updated: '2019-11-08 10:15:36'
tags: [devops, django, flask]
permalink: /articles/2019/11/08/1573179335967.html
---
![plug.jpg](https://img.hacpai.com/file/2019/11/plug-0f6b9010.jpg)

`app.py`
```
import importlib

Plugins = [
    "plugins.email.Email",
    "plugins.msg.Msg"
]

def sends(content):
    for p in Plugins:
        # module: plugins.email, className: Email
        module, className = p.rsplit('.',maxsplit=1)
        print("module: %s, className: %s" % (module,className) )
        # 相当from plugins import email
        mod = importlib.import_module(module)
        # 利用反射获取模块中的类名
        cls = getattr(mod, className)
        obj = cls()
        obj.send(content)

sends("hello world")
```
plugins包下添加模块
`email.py`
```
class Email:
    def send(self,content):
        print("This is plugin email => %s" % content)
```

`msg.py`
```
class Msg:
    def send(self,content):
        print("This is plugin Msg => %s" % content)
```
