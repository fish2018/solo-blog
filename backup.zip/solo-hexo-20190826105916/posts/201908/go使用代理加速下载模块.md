title: go使用代理加速下载模块
date: '2019-08-23 23:12:41'
updated: '2019-08-23 23:23:12'
tags: [go]
permalink: /articles/2019/08/23/1566573161661.html
---
### Go第三方包代理设置 — GOPROXY
#### 常用代理：
[https://goproxy.cn](https://goproxy.cn/)
[https://goproxy.io](https://goproxy.io/)
[https://athens.azurefd.net](https://athens.azurefd.net/)
[https://mirrors.aliyun.com/goproxy/](https://mirrors.aliyun.com/goproxy/)

#### 使用方法：
命令行
```
export GOPROXY=https://goproxy.cn
```
goland
![image.png](https://img.hacpai.com/file/2019/08/image-0ffe81eb.png)

